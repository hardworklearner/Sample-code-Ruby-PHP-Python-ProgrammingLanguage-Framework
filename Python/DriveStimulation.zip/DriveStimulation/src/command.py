car_direction = {}
car_direction["N"] = "North" 
car_direction["S"] = "South"
car_direction["E"] = "East"
car_direction["W"] = "West"

car_move_command = {"F": "Forward", "L": "Left", "R": "Right"}

car_turn = {"L": "Left", "R": "Right"}